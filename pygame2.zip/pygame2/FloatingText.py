import pygame
from BasicTypes import *
from GameObject import GameObject

START_DURATION = 3000
SHADOW_COLOR = (0,0,0,255) #BLACK

class FloatingText(GameObject):
    def __init__(self, startPosition: Position2D, text:str, color:Color, font:str = "LDFComicSansBold.ttf"):
        super().__init__()
        self.position = startPosition
        self.font = pygame.font.Font(f"fonts/{font}", 32)
        self.shadowFont = pygame.font.Font(f"fonts/{font}", 34)
        self.textRender = self.font.render(text, True, color)
        self.shadowRender = self.shadowFont.render(text, True, SHADOW_COLOR)
        self.speed = (0.1,2)
        self.gravity = (0,0.01)
        self.colision = False
        self.duration = START_DURATION

    def update(self):
        self.position = (self.position[0] - self.speed[0], self.position[1] - self.speed[1])
        self.speed = (self.speed[0] - self.gravity[0], self.speed[1] - self.gravity[1])
        self.duration -= 1
        self.shadowRender.set_alpha(int(255 * self.duration/START_DURATION))
        self.textRender.set_alpha(int(255 * self.duration/START_DURATION))
        return

    def draw(self,screen):
        shadowRect = self.shadowRender.get_rect()
        shadowRect.center = self.position
        screen.blit(self.shadowRender, shadowRect)

        textRect = self.textRender.get_rect()
        textRect.center = self.position
        screen.blit(self.textRender, textRect)
        return
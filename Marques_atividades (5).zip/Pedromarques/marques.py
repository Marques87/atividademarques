y = 0
z = 0

perg = ["""Qual o meu alimento favorito?""", """Qual o maior time do Brasil?""", 
             """Qual o menor time do Brasil?""", """Qual é melhor, Messi ou Ronaldo?""", """Qual o melhor professor do Sesi?""",
             """Qual o meu maior pato?""", """Qual o maior jogo da história?""", """Qual a melhor camisa do interclasse, a preta ou branca?""",
             """Qual o maior time do mundo?""", """Qual o melhor presidente que o Brasil já teve?"""]

resp2 = ["sorvete", "sport", "santa", "messi", "givânio", 
         "thyago", "minecraft", "preta", "barcelona", "lula"]

for pergunta in perg :
    resp = input(pergunta)
    respm = resp.lower()
    if respm == resp2[y]:
        z = z + 1
        print("Parabéns, pelo visto você acertou.")
    else:
        print("Errou hahaha")
    y = y + 1

print(f"Você acertou: {z}/10")
produtos = []
estoque = []
preços = []

concluir = False #Realiza o controle de repetição. 

while (not concluir):
    produto = input("Digite um produto: ")
    produtos.append(produto)
    
    estoquant = int(input("Digite a quantidade do produto: "))
    estoque.append(estoquant)

    preço = float(input("Digite o preço do produto: "))
    preços.append(preço)

    concluir = input("VocÊ deseja continuar a lista? s/n") == "n" #Transforma o concluir em True.

print("Segue abaixo todos os itens, com as respectivas informações: ")
for i in range(len(produtos)):
    print(f"Produto: {produtos[i]} - Quantidade no estoque: {estoque[i]} - Preço: {preços[i]}")

#ESCREVE ISSO NO BLOCO DE NOTAS:

import os 

filename = "arquivomarques"
file = open(filename, 'w')

for y in range(len(produtos)):
    outputline = f"Produto: {produtos[y]}\nEstoque do produto: {estoque[y]}\nPreços: {preços[y]}\n\n"
    file.write(outputline) 
file.close()

os.system(f"notepad {filename}") #Basicamente coloca isso no bloco de notas. 

input("Pressione ENTER para finalizar...")


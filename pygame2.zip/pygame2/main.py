import pygame
from pygame.locals import *
import Colors
import Map
import time
import MouseCursor
from BouncingBall import bouncingBall
import random
from FloatingText import FloatingText
from Quadrado import Square

class Main:
    def __init__(self):
        self.windowWidth = 960
        self.windowHieght = 640
        self.boundaries = (0,0,self.windowWidth,self.windowHieght)
        self.mouse = MouseCursor.MouseCursor()
        self.gameObjects = []

        screenSize = (self.windowWidth, self.windowHieght)
        self.screen = pygame.display.set_mode(screenSize)
        
        self.running = False

    def start(self):
        pygame.init()
        self.running = True
        while self.running:
            self.update()
            self.draw()
        pygame.quit()

    def getRandomSpeed(self):
        vx = random.random()*1
        vy = random.random()*1
        return(vx,vy)

    def getRnadomColor(self):
        r = random.randint(0,255)
        g = random.randint(0,255)
        b = random.randint(0,255)
        # a = random.randint(100,255)
        a = 128
        return (r,g,b,a)

    def createBouncingBall(self):
        position = pygame.mouse.get_pos()
        speed = self.getRandomSpeed()
        color = self.getRnadomColor()
        radius = random.randint(1,30)
        self.gameObjects.append(bouncingBall(position,speed,color,radius,self.boundaries))
    
    def update(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.running = False
            if event.type == pygame.MOUSEBUTTONUP:
                self.createBouncingBall()
                self.createSquare()
                self.gameObjects.append(FloatingText(pygame.mouse.get_pos(), str(random.randint(0,1000)), Colors.GREEN))
        self.mouse.update()
        for gameobject in self.gameObjects:
            gameobject.update()
        
        return

    def draw(self):
        self.screen.fill(Colors.BLACK)
        
        for gameObject in self.gameObjects:
            gameObject.draw(self.screen)
        
        self.mouse.draw(self.screen)
        
        pygame.display.update()
        return

    def createSquare(self):
        position = pygame.mouse.get_pos()
        speed = self.getRandomSpeed()
        color = self.getRnadomColor()
        size = random.randint(1,30)
        self.gameObjects.append(Square(position,speed,color,size,self.boundaries))

mainGame = Main()
mainGame.start()

import pygame
from pygame.locals import *

import Config
import Camera

class Tile:
    def __init__(self, x, y, textureFile):
        self.x = x  # X-coordinate of the tile
        self.y = y  # Y-coordinate of the tile
        self.texture = pygame.image.load(textureFile)
        self.texture = pygame.transform.scale(self.texture, (TILE_SIZE, TILE_SIZE))

    def draw(self, screen:Surface, camera:Camera):
        draw_x = (self.x - camera.x) * TILE_SIZE
        draw_y = (self.y - camera.y) * TILE_SIZE
        screen.blit(sprite,(draw_x, draw_y))

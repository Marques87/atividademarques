import time 
import math
g = float(10)

print("Olá, caro espectador.")
time.sleep(0)
print("Você sabia que está conversando com uma inteligência artificial? Incrível né? (:")
time.sleep(0)
print("Espero que goste da nossa conversa.")
time.sleep(0)
print("Esse programa basicamente vai fazer uns cálculos aí, sou esperto e você também, então você já deve saber o que ele faz.")
time.sleep(0)
print("Eu sei que você sabe.")
time.sleep(0)

cordx = float(input("Primeiro coloque o valor da coordenada x: \n"))
cordy = float(input("Agora coloque o valor da coordenada y: \n"))
força = float(input("Insira a força em newtons: \n"))
angulo = float(input("Por último, coloque o ângulo em graus: \n"))

angulorad = math.radians(angulo)
seno = math.sin(angulorad)
cosseno = math.cos(angulorad)



print("Espere a magia acontecer... Esqueci de dizer que a bala tem 0.5kg, blz?")

massa = 0.5
def veloini():
    veini = força * massa
    return veini

print(f"A velocidade inicial é: {veloini()}")

# __________________________________________________________________ 

def veloiniy():
    veliniy = veloini() * seno
    return veliniy

def tempomax():
    iy = 2 * veloiniy()
    iym = iy / g
    return iym 

print(f"O tempo total de voo é: {tempomax() / 2:.4f}")

# __________________________________________________________________

def veloinix():
    ui = veloini() * cosseno
    return ui
velox = veloinix()


def xmax():
    uin = (veloinix() * tempomax())
    uin2 = cordx + uin
    return uin2 

print(f"Local de queda: {xmax():.4f}")

#VELOCIDADE VERTICAL E HORIZONTAL EM CADA INSTANTE DO VOO

finalizar = False

o = input("Você quer colocar um tempo específico para saber a velocidade(y ou x) \n s ou n") 
if o == "s":
   while(not finalizar):
        t = float(input("Digite aqui o tempo que você quer (lembre que o limite é o tempo máximo): "))
        if t < tempomax() / 2:
            finalizar = True
           
            def veloy1(t):
                g_local = -g
                haha = g_local * t
                veloy22 = veloiniy() + haha
                return veloy22
            print(f"A velocidade y nesse tempo é: {veloy1(t):.4f}")
        else:
            print("Escreva um número menor do que o tempo máximo.")
else:
    print("Vai ser o tempo máximo então.")
    def veloy2():
        g_local = -g
        haha2 = g_local * tempomax() / 2
        veloy21 = veloiniy() + haha2 
        return veloy21
    print(f"A velocidade y no tempo máximo é: {veloy2():.4f}")

def dist():
    my = xmax() - cordx
    return my 

print(f"A distância entre o ponto de lançamento e local da queda: {dist():.3f}")
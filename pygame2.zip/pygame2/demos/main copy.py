"""Move an image with the mouse."""

import pygame
from pygame.locals import *
from colors import *

pygame.init()

windowWidth = 640
windowHeight = 320

screen = pygame.display.set_mode((windowWidth, windowHeight))
running = True

grass_img = pygame.image.load('grass.png')
mouse_img = pygame.image.load('mouse.png')

grass_img.convert()
rect = grass_img.get_rect()
w_step = rect.width
h_step = rect.height

rect.center = (windowWidth//2, windowHeight//2)

moving = False
mousePosition = rect
def handleEvents(moving, mousePosition):
    for event in pygame.event.get():
        if event.type == MOUSEMOTION:
            mousePosition.move_ip(event.rel)
        if event.type == QUIT:
            running = False

fontFile = "fonts/ActrociousRegular-2Oo2K.ttf"
font = pygame.font.Font(fontFile, 32)
def drawText(display, text, x, y, color):
    text_render = font.render(text, True, color)
    text_rect = text_render.get_rect()
    text_rect.left = x
    text_rect.top = y
    display.blit(text_render, text_rect)

def drawBackground():
    for i in range(windowWidth // w_step):
        for j in range(windowHeight // h_step):
            x = i * w_step
            y = j * h_step
            screen.blit(grass_img,(x,y))

def drawMouse():
    screen.blit(mouse_img, mousePosition.center)

while running:
    handleEvents(moving, mousePosition)
    screen.fill(BLACK)
    drawBackground()
    drawMouse()
    drawText(screen, "Teste de texto", 10,10, WHITE)
    pygame.display.update()

pygame.quit()
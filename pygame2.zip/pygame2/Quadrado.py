import pygame
from pygame.locals import *

from BasicTypes import *
from GameObject import GameObject

class Square(GameObject):
    def __init__(self, position: Position2D, speed: Vector2D, color:Color, size:int, boundaries:Rectangle2D):
        super().__init__()
        self.position = position
        self.speed = speed
        self.color = color
        self.size = size
        self.boundaries = boundaries
        self.texture = pygame.image.load("images/bird.png")

    def update(self):
        self.move(self.speed)
        # if the ball
        
        x = self.position[0]
        y = self.position[1]

        left = self.boundaries[0] + self.size
        top = self.boundaries[1] + self.size
        right = self.boundaries[2] - self.size
        botton = self.boundaries[3] - self.size

        vx = self.speed[0]
        vy = self.speed[1]

        if x < left     : x = left      ; vx = -vx
        if x > right    : x = right     ; vx = -vx
        if y < top      : y = top       ; vy = -vy
        if y > botton   : y = botton    ; vy = -vy

        self.position = (x,y)
        self.speed = (vx,vy)

    def draw(self, screen):
        x,y = self.position
        s = self.size
        r = (x,y,s,s)
        drawx, drawy = self.position
        drawx -= self.size
        drawy -= self.size
        screen.blit(self.texture,(drawx,drawy))
        pygame.draw.rect(screen,self.color,r)
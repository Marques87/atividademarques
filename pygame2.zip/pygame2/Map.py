import numpy as np
import pygame
import Config
import Terrain
import GameObject

class Map(GameObject.GameObject):
    def __init__(self, width:int, height:int):
        self.width = width
        self.height = height
        self.map = np.zeros((width,height))

    def draw(self, screen):
        for x in range(self.width):
            for y in range(self.height):
                terrainId = int(self.map[x,y])
                texture = Terrain.texture[terrainId]
                draw_x = x * Config.TILE_SIZE
                draw_y = y * Config.TILE_SIZE
                screen.blit(texture,(draw_x,draw_y))
    
    def getRenderSize(self):
        return (self.width * Config.TILE_SIZE, self.height * Config.TILE_SIZE)
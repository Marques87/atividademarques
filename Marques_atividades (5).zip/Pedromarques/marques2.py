alunos = []
notas = []

concluir = False

while (not concluir):
    print("Digite o nome do aluno:")
    nomeAluno = input()
    print("Digite a nota do aluno")
    notaAluno = int(input())

    if(notaAluno < 5): print("Misericórdia")
    elif(notaAluno < 7): print("Tá quase")
    else: print("Passou")

    alunos.append(nomeAluno)
    notas.append(notaAluno)

    print("Deseja inserir outra nota? (s/n)")
    concluir = input() == "n"

for i in alunos:
        print(f"{alunos}") 
        print(f"{notas}")
       
 

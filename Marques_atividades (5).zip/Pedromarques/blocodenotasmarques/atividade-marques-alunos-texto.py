#Matheus Marques

arquivo = open("Alunos.txt", encoding = "utf-8", mode = "r+") #Arquivo com o nome e nota dos alunos. utf-8 é só pra formatação do texto ficar correta

aprovados = []
reprovados = []

for linha in arquivo: #Vai ler cada linha do arquivo.
    linha = linha.strip() #Remove o "\n"
    nota = float(linha.split(":")[1].strip()) #Separa a string com base no ":"
    if nota >= 7:
        aprovados.append(linha) #Adiciona na lista dos aprovados. (A linha toda)
    else:
        reprovados.append(linha) #Adiciona na lista dos reprovados. (A linha toda)

arquivo.close()

arquivo_aprovados = open("Aprovados.txt", encoding = "utf-8", mode = "w") 

for nomes in aprovados: #Escreve os nomes da lista dos aprovados.
    arquivo_aprovados.write(f"{nomes}\n")

arquivo_aprovados.close()

arquivo_reprovados = open("Reprovados.txt", encoding = "utf-8", mode = "w")

for nomes in reprovados: #Escreve os nomes da lista dos reprovados.
    arquivo_reprovados.write(f"{nomes}\n")

arquivo_reprovados.close()

print("Olhe os arquivos 'Aprovados.txt' e 'Reprovados.txt'")
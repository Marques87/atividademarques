x = 0
numero = []
resposta = []
z = 0
y = 0

opera = ["""soma do primeiro com o segundo?""", """multiplicação do terceiro com o quarto?""", 
         """divisão do quinto com o sexto?""", """potencia do sétimo com o oitavo?""", """subtração do nono com o décimo?"""]

for _ in range(10):
    num = float(input(f"Digite um número:"))
    print(f"O número que você digitou foi {num}")
    numero.append(num)

soma = numero[0] + numero[1]
multi = numero[2] * numero[3]
divisao = numero[4] / numero[5]
potencia = numero[6] ** numero[7]
sub = numero[8] - numero[9]

opera2 = [soma, multi, divisao, potencia, sub]

for k in range(5):
    resp = float(input(f"Qual a {opera[x]}:"))
    x = x + 1 
    if resp == opera2[y]:
        z = z + 1
    y = y + 1
    resposta.append(resp)


print(f"A soma do primeiro com o segundo: {soma}")
print(f"A multiplicação do terceiro com o quarto: {multi}")
print(f"A divisão do quinto com o sexto: {divisao}")
print(f"A o sétimo elevado ao oitavo: {potencia}")
print(f"A subtração do nono com o décimo: {sub}")

print(f"Você acertou: {z}/5")
import pygame
from BasicTypes import *

class GameObject:
    def __init__(self):
        self.position = (0,0)
        self.texture = None
    
    def loadTexture(self, filename):
        self.texture = pygame.image.load(filename)

    def move(self, speed:Vector2D):
        x = self.position[0] + speed[0]
        y = self.position[1] + speed[1]
        self.position = (x,y)

    def moveTo(self,position:Position2D):
        self.position = position

    def update(self):
        pass
    
    def draw(self, screen):
        screen.blit(self.texture, self.position)
        pass
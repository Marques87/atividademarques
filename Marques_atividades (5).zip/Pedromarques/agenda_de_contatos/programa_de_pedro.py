import os

Agenda = {
    "pessoais": [],
    "profissionais": [],
    "romanticos": []
}

def abrir_Agenda():
    try:
        with open("Agenda.txt", "r") as arquivo:
            linhas = [linha.strip() for linha in arquivo.readlines()]
            if len(linhas) == 3:
                Agenda["pessoais"], Agenda["profissionais"], Agenda["romanticos"] = [linha.split(",") for linha in linhas]
            else:
                print("Arquivo da agenda está incompleto ou corrompido.")
    except FileNotFoundError:
        print("Arquivo da agenda não encontrado. Criando um novo.")

def listar_contat(categoria):
    print(f"Contatos {categoria.capitalize()}:")
    for contato in Agenda[categoria]:
        print(contato)

def criar_contat():
    categoria = input("Categoria (pessoais/profissionais/romanticos): ").lower()
    if categoria in Agenda:
        nome = input("Nome: ")
        endereco = input("Endereço: ")
        telefone = input("Telefone: ")
        novo_contato = f"{nome}, {endereco}, {telefone}"
        Agenda[categoria].append(novo_contato)
        print("Contato criado com sucesso!")
    else:
        print("Categoria inválida. O contato não foi criado.")

def editar_contat():
    categoria = input("Digite a categoria do contato que deseja editar (pessoais/profissionais/romanticos): ").lower()
    
    if categoria in Agenda:
        listar_contat(categoria)
        indice = int(input("Digite o índice do contato que deseja editar: "))
        if 0 <= indice < len(Agenda[categoria]):
            nome = input("Nome: ")
            endereco = input("Endereço: ")
            telefone = input("Telefone: ")
            novo_contato = f"{nome}, {endereco}, {telefone}"
            Agenda[categoria][indice] = novo_contato
            print("Contato editado com sucesso!")
        else:
            print("Índice de contato inválido.")
    else:
        print("Categoria inválida. Não é possível editar o contato.")

def excluir_contat():
    categoria = input("Digite a categoria do contato que deseja excluir (pessoais/profissionais/romanticos): ").lower()
    
    if categoria in Agenda:
        listar_contat(categoria)
        indice = int(input("Digite o índice do contato que deseja excluir: "))
        if 0 <= indice < len(Agenda[categoria]):
            del Agenda[categoria][indice]
            print("Contato excluído com sucesso!")
        else:
            print("Índice de contato inválido.")
    else:
        print("Categoria inválida. Não é possível excluir o contato.")

def salvar_agend():
    with open("Agenda.txt", "w") as arquivo:
        for categoria in Agenda:
            arquivo.write("\n".join(Agenda[categoria]) + "\n")

def fechar_agend():
    salvar = input("Deseja salvar a agenda antes de fechar? (s/n): ").lower()
    if salvar == 's':
        salvar_agend()
    elif salvar == 'n':
        print("Agenda fechada sem salvar.")
    else:
        print("Opção inválida. A agenda não foi fechada.")

def main():
    abrir_Agenda()
    
    while True:
        print("\nOpções:")
        print("1 - Listar contatos")
        print("2 - Criar contato")
        print("3 - Editar contato")
        print("4 - Excluir contato")
        print("5 - Fechar agenda")
        opcao = input("Escolha uma opção (1/2/3/4/5): ")
        
        if opcao == '1':
            categoria = input("Digite a categoria (pessoais/profissionais/romanticos): ").lower()
            if categoria in Agenda:
                listar_contat(categoria)
            else:
                print("Categoria inválida.")
        elif opcao == '2':
            criar_contat()
        elif opcao == '3':
            editar_contat()
        elif opcao == '4':
            excluir_contat()
        elif opcao == '5':
            fechar_agend()
            break
        else:
            print("Opção inválida. Tente novamente.")

if __name__ == "__main__":
    main()

import time 

a = float(input("Digite um número: "))
print(f"Você digitou o número: {a}")
b = float(input("Digite outro número: "))
print(f"Você digitou o número: {b}")

print("Vamos fazer a média desses dois números, espere apenas 1 segundo.")

def media(a, b):
    c = a + b
    z = c / 2
    return z 

time.sleep(1)
print(f"A média entre {a} e {b} é: {media(a,b):.4f}")

# e = float(input("Insira outro valor: "))
# print(f"O valor que você digitou foi: {e}")
# pe = float(input("Insira um peso para o valor anterior: "))
# print(f"O peso que você digitou foi: {pe}")
# f = float(input("Insira outro valor: "))
# print(f"O valor que você digitou foi: {f}")
# pf = float(input("Insira um peso para o valor anterior"))
# print(f"O peso que você digitou foi: {pf}")

# print("Espere 1 segundo e vamos fazer a média ponderada.")

# def mediaponderada(e, f, pe, pf):
#     t = e*pe + f*pf
#     h = pe + pf
#     l = t/h
#     return l

# time.sleep(1)

# print(f"A média ponderada entre {e} com peso {pe} e {f} com peso {pf} é: {mediaponderada(e, f, pe, pf):.4f}")

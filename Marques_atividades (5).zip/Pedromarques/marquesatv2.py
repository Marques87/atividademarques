#Função
#Definição, Subrotina, Método, Procedimento

def media(a,b):
    s = a + b
    m = s/2
    return m

def mediaponderada(a, b, pa, pb):
    s = a*pa + b*pb
    m = pa + pb 
    p = s/m
    return m 
print(media(7,8))
print(mediaponderada(4, 5, 2, 3))

# Implemente um programa em python, que receba dois valores e imprima a médica entre eles
# defina uma função customizada para calcular a média.


import pygame
from pygame.locals import *

from BasicTypes import *
from GameObject import GameObject


class bouncingBall(GameObject):
    def __init__(self, position: Position2D, speed: Vector2D, color:Color, radius:int, boundaries:Rectangle2D):
        super().__init__()
        self.position = position
        self.speed = speed
        self.color = color
        self.radius = radius
        self.boundaries = boundaries

    def update(self):
        self.move(self.speed)
        # if the ball
        
        x = self.position[0]
        y = self.position[1]

        left = self.boundaries[0] + self.radius
        top = self.boundaries[1] + self.radius
        right = self.boundaries[2] - self.radius
        botton = self.boundaries[3] - self.radius

        vx = self.speed[0]
        vy = self.speed[1]

        if x < left     : x = left      ; vx = -vx
        if x > right    : x = right     ; vx = -vx
        if y < top      : y = top       ; vy = -vy
        if y > botton   : y = botton    ; vy = -vy

        self.position = (x,y)
        self.speed = (vx,vy)

    def draw(self, screen):
        pygame.draw.circle(screen,self.color,self.position,self.radius)